# Ingeniería de Sistemas — Universidad de la Amazonia

Página web informativa sobre el programa de pregrado **Ingeniería de Sistemas** de la
Universidad de la Amazonia, desarrollada como **Entregable 1** de la asignatura
Programación Web.

Hecha en HTML y CSS puro (sin frameworks), con el mismo enfoque visto en clase:
reset CSS, `box-sizing: border-box`, **Grid** mobile-first con `grid-template-areas`,
**Flexbox** para los componentes, `position: sticky` para el menú y la barra lateral,
pseudo-clases (`:hover`, `:nth-child`, `:focus-visible`) y nombres de clase estilo **BEM**.

## Estructura

```
.
├── index.html
├── css/
│   └── styles.css
└── README.md
```

## Contenido

- Propósito de formación, misión, visión y perfil de egreso.
- Ficha técnica (título, modalidad, jornada, duración, créditos, SNIES, acuerdos).
- Admisión: requisitos, inversión y enlace de inscripción.
- Contacto y ubicación de la coordinación del programa.

La información se tomó de la página oficial del programa:
<https://www.uniamazonia.edu.co/inicio/index.php/es/programas/pregrado/ingenieria/ingenieria-de-sistemas.html>
(consultada el 4 de octubre de 2026). Este sitio es un proyecto académico y no reemplaza
los canales oficiales de la universidad.

## Ver en local

No necesita instalación. Abre `index.html` con doble clic, o si tienes VS Code, usa la
extensión **Live Server** → clic derecho sobre `index.html` → "Open with Live Server".

## Publicar en GitHub

```bash
git init
git add .
git commit -m "Entregable 1: pagina Ingenieria de Sistemas"
git branch -M main
git remote add origin https://github.com/<tu-usuario>/<tu-repositorio>.git
git push -u origin main
```

Recuerda que el repositorio debe ser **público**.

## Desplegar en Vercel

1. Entra a <https://vercel.com/> e inicia sesión con tu cuenta de GitHub.
2. Clic en **Add New → Project**.
3. Importa el repositorio que acabas de subir.
4. En "Framework Preset" deja **Other** (es HTML/CSS puro, sin build).
5. Clic en **Deploy** y espera a que termine.
6. Copia la URL que te entrega Vercel (algo como `https://tu-repo.vercel.app`).

## Entrega

Antes de las 7:00 a. m. del lunes 5 de octubre de 2026, enviar al correo
`w.patino@udla.edu.co` un mensaje con:

- La URL del repositorio público de GitHub.
- La URL de la página desplegada en Vercel.
